from . import poly_regression, ridge_regression_mnist

__all__ = ["poly_regression", "ridge_regression_mnist"]
